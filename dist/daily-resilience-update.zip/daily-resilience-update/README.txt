Extract daily-resilience-update inside the existing warranty-main folder.
When no daily run is active, double-click INSTALL_ONLY.bat to install without running another refresh.
Use INSTALL_AND_RUN.bat if you also want a full immediate update.
All patches are checked before installation; an unrecognized version is rejected.
Original code is backed up in logs. Credentials and existing data are not replaced.
The existing Issue Position credential bundle must still be present on Planning.
Exit 0 = complete, 2 = completed with auxiliary warnings, other = core failure.
