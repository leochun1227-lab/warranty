@echo off
call "%~dp0INSTALL_AND_RUN.bat" --install-only
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
