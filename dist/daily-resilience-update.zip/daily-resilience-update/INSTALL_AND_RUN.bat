@echo off
setlocal
cd /d "%~dp0"
set "TARGET=%~dp0.."
if not exist "%TARGET%\run_daily_5pm_mandt800_rejection_filter.bat" (
  echo Extract this folder INSIDE your existing warranty-main folder.
  pause
  exit /b 1
)
echo Close any running daily update before installing this repair.
python "%~dp0install_daily_resilience_update.py" --warranty-root "%TARGET%"
if errorlevel 1 (
  echo Repair not installed. Keep the error message above.
  pause
  exit /b 1
)
if /I "%~1"=="--install-only" exit /b 0
echo Starting the existing daily update. Progress is in warranty-main\logs.
call "%TARGET%\run_daily_5pm_mandt800_rejection_filter.bat"
set "RESULT=%ERRORLEVEL%"
if "%RESULT%"=="0" echo SUCCESS: daily update and dashboard publication checks passed.
if "%RESULT%"=="2" echo PARTIAL: core fetch completed, but some page updates need attention. See the daily log.
if not "%RESULT%"=="0" if not "%RESULT%"=="2" echo FAILED: core fetch failed. See the daily log.
pause
exit /b %RESULT%
