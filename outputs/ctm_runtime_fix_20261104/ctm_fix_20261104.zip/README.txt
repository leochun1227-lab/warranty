CTM repair - 2026-11-04

On the planning PC:
1. Wait for any current daily task to finish or stop it before replacing code.
2. Back up the two existing files in C:\Users\planning\Desktop\warranty-main.
3. Copy both .py/.mjs files from this ZIP into that folder, replacing the same filenames.
4. Run the normal daily update again and check its new log.

Fixes:
- Accept an RTDB-omitted empty repairCostDistribution only when the same period explicitly reports approvedTickets=0 and approvedAmount=0. Missing nonzero or unverified data still fails without overwriting dashboardSummary.
- Resolve @oai/artifact-tool from the project's installed dependency (as the successful workbook generators already do), instead of a Leo-specific absolute path. ARTIFACT_TOOL_MODULE remains supported.
- Prevent the PPT cover title from overlapping its subtitle.

No credentials, SAP paging settings, billing settings or production data are included or changed by this package.
Validated locally: 8 summary regression tests; real 4-slide PPT export using the project dependency; PPTX ZIP/XML validation.
This package has not been installed or run on the planning PC.
